package com.example.homeworkinternetjson;

public class InforList {
    String name;
    String phone;
    String email;
    String street;
    String city;
    String userName;
    String uRl;

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setuRl(String uRl) {
        this.uRl = uRl;
    }

    public String getEmail() {
        return email;
    }

    public String getStreet() {
        return street;
    }

    public String getCity() {
        return city;
    }

    public String getUserName() {
        return userName;
    }

    public String getuRl() {
        return uRl;
    }
}
